import React from 'react';
import DefaultLayout from '../components/DefaultLayout';

const Contact = () => {

  return (
    <DefaultLayout>
    <div>
   <h2> Phone : 763 234 2445</h2>
   <h2>Adress : Bus Depot, No. 2 And 3, <br></br> Nelson Mandela Rd, opposite K.S.R.T.C,<br></br> Bannimantap, Mysuru,<br></br> Karnataka 570015</h2>
    </div>
    </DefaultLayout>
  );
};

export default Contact