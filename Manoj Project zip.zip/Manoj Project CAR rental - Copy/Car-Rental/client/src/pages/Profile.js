import React from 'react';
import DefaultLayout from '../components/DefaultLayout';



const Profile = () => {

  const user = JSON.parse(localStorage.getItem('user'))
  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <DefaultLayout>
    <div>
      <h2>User Profile</h2>
      <p>Name: {user.username}</p>
    </div>
    </DefaultLayout>
  );
};

export default Profile;